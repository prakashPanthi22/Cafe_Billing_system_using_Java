package caffe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnections {
	static Connection c;
	static Connection connect()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded");
			c = DriverManager.getConnection("jdbc:mysql://localhost:3306/cafemanagment","root","ramtara");
			System.out.println("Connected");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return c;
	}
	public static void main(String[] args) {
		connect();
	}

}
