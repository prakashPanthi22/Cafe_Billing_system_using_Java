package caffe;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
 

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.Color;
 

 
 



import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

 

import javax.swing.JButton;
import javax.swing.JLabel;

public class Menu extends JFrame implements ActionListener {
	 
	 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel panel_2;
	private JButton btnNewButton;
	private JPanel panel_4;
	private JButton button;
	private JComponent contentPane1;
	private JButton btnlogin;
	private JLabel lblCoffeMocha;
	private JLabel lblHazelnntLatte;
	private JLabel lblIrishCappnccino;
	private JLabel lblColdCoffees;
	private JLabel lblIcedEskimo;
	private JLabel lblKappiNirwana;
	private JLabel lblDarkFrappe;
	private JLabel lblTropicalIcebera;
	private JLabel lblRs;
	private JLabel lblRs_1;
	private JLabel label;
	private JLabel lblRs_5;
	private JLabel label_2;
	private JLabel lblRs_2;
	private JLabel lblRs_3;
	private JLabel lblRs_4;
	private JLabel lblCafeMenu;
	 
	

	public Menu() {
		getContentPane().setFont(new Font("Stencil", Font.BOLD, 10));
		setSize(getMaximumSize());
		getContentPane().setLayout(null);
		
		
		
		
		contentPane1 = new JPanel(){
			/**
				 * 
				 */
				private static final long serialVersionUID = 1L;

			public void paintComponent(Graphics g){
				Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/bgecc.jpg"));
				g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
				
			}
		};
		contentPane1.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane1);
		contentPane1.setLayout(null);
		
		
		
		 
		
		
		
		
		
		JPanel panel = new JPanel(){
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public void paintComponent(Graphics g){
				Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/menu2.jpg"));
				g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
				
			}
		};
		panel.setForeground(new Color(0, 0, 0));
		panel.setBounds(39, 107, 437, 392);
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Hot Coffees");
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("Vijaya", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(89, 22, 248, 45);
		panel.add(lblNewLabel);
		
		JLabel lblVanillaCappnccino = new JLabel("Vanilla Cappnccino");
		lblVanillaCappnccino.setForeground(new Color(0, 0, 0));
		lblVanillaCappnccino.setFont(new Font("Vijaya", Font.BOLD | Font.ITALIC, 40));
		lblVanillaCappnccino.setBounds(10, 94, 270, 45);
		panel.add(lblVanillaCappnccino);
		
		lblCoffeMocha = new JLabel("Coffe Mocha");
		lblCoffeMocha.setForeground(new Color(0, 0, 0));
		lblCoffeMocha.setFont(new Font("Vijaya", Font.BOLD | Font.ITALIC, 40));
		lblCoffeMocha.setBounds(10, 165, 270, 45);
		panel.add(lblCoffeMocha);
		
		lblHazelnntLatte = new JLabel("Hazelnnt Latte");
		lblHazelnntLatte.setForeground(new Color(0, 0, 0));
		lblHazelnntLatte.setFont(new Font("Vijaya", Font.BOLD | Font.ITALIC, 40));
		lblHazelnntLatte.setBounds(10, 234, 270, 45);
		panel.add(lblHazelnntLatte);
		
		lblIrishCappnccino = new JLabel("Irish Cappnccino");
		lblIrishCappnccino.setForeground(Color.PINK);
		lblIrishCappnccino.setFont(new Font("Vijaya", Font.BOLD | Font.ITALIC, 40));
		lblIrishCappnccino.setBounds(10, 298, 270, 45);
		panel.add(lblIrishCappnccino);
		
		lblRs = new JLabel("Rs.250");
		lblRs.setForeground(new Color(0, 0, 0));
		lblRs.setFont(new Font("Vani", Font.BOLD | Font.ITALIC, 22));
		lblRs.setBounds(297, 109, 86, 29);
		panel.add(lblRs);
		
		lblRs_1 = new JLabel("Rs.300");
		lblRs_1.setForeground(new Color(0, 0, 0));
		lblRs_1.setFont(new Font("Vani", Font.BOLD | Font.ITALIC, 22));
		lblRs_1.setBounds(297, 180, 86, 29);
		panel.add(lblRs_1);
		
		label = new JLabel("Rs.250");
		label.setForeground(new Color(0, 0, 0));
		label.setFont(new Font("Vani", Font.BOLD | Font.ITALIC, 22));
		label.setBounds(290, 249, 86, 29);
		panel.add(label);
		
		lblRs_5 = new JLabel("Rs.180");
		lblRs_5.setForeground(new Color(0, 0, 0));
		lblRs_5.setFont(new Font("Vani", Font.BOLD | Font.ITALIC, 22));
		lblRs_5.setBounds(290, 313, 86, 29);
		panel.add(lblRs_5);
		
		JPanel panel_1 = new JPanel() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public void paintComponent(Graphics g){
				Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/coldccc.jpg"));
				g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
				
			}
		};
		panel_1.setBounds(555, 107, 437, 392);
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		lblColdCoffees = new JLabel("Cold Coffees");
		lblColdCoffees.setForeground(new Color(0, 0, 139));
		lblColdCoffees.setFont(new Font("Vijaya", Font.BOLD | Font.ITALIC, 50));
		lblColdCoffees.setBounds(64, 11, 248, 45);
		panel_1.add(lblColdCoffees);
		
		lblIcedEskimo = new JLabel("Iced Eskimo");
		lblIcedEskimo.setForeground(new Color(0, 0, 139));
		lblIcedEskimo.setFont(new Font("Vijaya", Font.BOLD | Font.ITALIC, 50));
		lblIcedEskimo.setBounds(20, 104, 230, 45);
		panel_1.add(lblIcedEskimo);
		
		lblKappiNirwana = new JLabel("Kappi Nirwana");
		lblKappiNirwana.setForeground(new Color(0, 0, 139));
		lblKappiNirwana.setFont(new Font("Vijaya", Font.BOLD | Font.ITALIC, 50));
		lblKappiNirwana.setBounds(20, 161, 271, 45);
		panel_1.add(lblKappiNirwana);
		
		lblDarkFrappe = new JLabel("Dark Frappe");
		lblDarkFrappe.setForeground(new Color(0, 0, 139));
		lblDarkFrappe.setFont(new Font("Vijaya", Font.BOLD | Font.ITALIC, 50));
		lblDarkFrappe.setBounds(20, 226, 230, 45);
		panel_1.add(lblDarkFrappe);
		
		lblTropicalIcebera = new JLabel("Tropical Icebera");
		lblTropicalIcebera.setForeground(new Color(0, 0, 139));
		lblTropicalIcebera.setFont(new Font("Vijaya", Font.BOLD | Font.ITALIC, 50));
		lblTropicalIcebera.setBounds(20, 295, 292, 45);
		panel_1.add(lblTropicalIcebera);
		
		label_2 = new JLabel("Rs.250");
		label_2.setForeground(new Color(0, 0, 139));
		label_2.setFont(new Font("Vani", Font.BOLD | Font.ITALIC, 22));
		label_2.setBounds(316, 121, 86, 29);
		panel_1.add(label_2);
		
		lblRs_2 = new JLabel("Rs.190");
		lblRs_2.setForeground(new Color(0, 0, 139));
		lblRs_2.setFont(new Font("Vani", Font.BOLD | Font.ITALIC, 22));
		lblRs_2.setBounds(316, 178, 86, 29);
		panel_1.add(lblRs_2);
		
		lblRs_3 = new JLabel("Rs.150");
		lblRs_3.setForeground(new Color(0, 0, 139));
		lblRs_3.setFont(new Font("Vani", Font.BOLD | Font.ITALIC, 22));
		lblRs_3.setBounds(316, 243, 86, 29);
		panel_1.add(lblRs_3);
		
		lblRs_4 = new JLabel("Rs.200");
		lblRs_4.setForeground(new Color(0, 0, 139));
		lblRs_4.setFont(new Font("Vani", Font.BOLD | Font.ITALIC, 22));
		lblRs_4.setBounds(316, 311, 86, 29);
		panel_1.add(lblRs_4);
		
		                                 // --------------Home----------
		
		panel_2 = new JPanel() {
		 
		/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics g){
			Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/home.jpg"));
			g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
		}};
		panel_2.setBounds(316, 616, 80, 87);
		getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		btnNewButton = new JButton("");
		btnNewButton.setBounds(0, 0, 80, 87);
		panel_2.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object butt=e.getSource();
				if(butt==btnNewButton)
				{
					dispose();
					new Home();
				
				}
			}
		});
		btnNewButton.setContentAreaFilled(false);
		btnNewButton.setOpaque(false);
		
		
		   // ------ billing pg link-------
		panel_4 = new JPanel() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public void paintComponent(Graphics g) {
				Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/Bill.jpg"));
				g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
			}
		};
		panel_4.setBounds(672, 616, 80, 87);
		panel_4.setLayout(null);
		getContentPane().add(panel_4);
		
		button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Object butt=e.getSource();
				if(butt==button)
				{
					dispose();
					new Billing();
				
				}
			
			}
		});
		button.setOpaque(false);
		button.setContentAreaFilled(false);
		button.setBounds(0, 0, 80, 87);
		panel_4.add(button);
		
		JPanel panel_3 = new JPanel()	{
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public void paintComponent(Graphics g) {
				Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/loginss.jpg"));
				g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
			}
		
		};
		panel_3.setBounds(481, 616, 122, 87);
		contentPane1.add(panel_3);
		panel_3.setLayout(null);
		
		btnlogin = new JButton("");
		btnlogin.setOpaque(false);
		btnlogin.setContentAreaFilled(false);
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object butt=e.getSource();
				if(butt==btnlogin)
				{
					dispose();
					new Login();
				
				}
				
			}
		});
		btnlogin.setBounds(0, 0, 122, 87);
		panel_3.add(btnlogin);
		
		lblCafeMenu = new JLabel("Cafe Menu");
		lblCafeMenu.setBackground(new Color(192, 192, 192));
		lblCafeMenu.setForeground(new Color(0, 128, 0));
		lblCafeMenu.setFont(new Font("Vijaya", Font.BOLD | Font.ITALIC, 67));
		lblCafeMenu.setBounds(382, 11, 370, 69);
		contentPane1.add(lblCafeMenu);
		
		 
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
	 
		new Menu();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}	
}
