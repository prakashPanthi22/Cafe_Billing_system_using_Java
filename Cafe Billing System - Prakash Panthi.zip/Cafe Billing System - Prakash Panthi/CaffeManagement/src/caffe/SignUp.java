package caffe;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;



public class SignUp extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tname;
	private JPasswordField pass1;
	private JButton submit;
	private JButton   cancel;
	private JTextField taddress;
	private JTextField tm_no;
	private JPanel panel_1;
	private JRadioButton f;
	private JRadioButton m;
	private JLabel lblCity;
	private JComboBox<String> tcity;
	private JLabel lblId;
	private JTextField tid;
  int id;
  private JPasswordField passwordField;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SignUp() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 748, 654);
		contentPane = new JPanel(){
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public void paintComponent(Graphics g){
				Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/signup.jpg"));
				g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
				
			}
		};
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel(" ");
		lblNewLabel.setVerifyInputWhenFocusTarget(false);
		lblNewLabel.setBounds(163, 145, 385, -6);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setVerifyInputWhenFocusTarget(false);
		panel.setBorder(new LineBorder(new Color(238, 232, 170), 3, true));
		panel.setBounds(68, 116, 427, 462);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(37, 108, 109, 35);
		panel.add(lblPassword);
		lblPassword.setFont(new Font("Aharoni", Font.PLAIN, 19));
		
		JLabel label = new JLabel("Username");
		label.setBounds(37, 62, 109, 35);
		panel.add(label);
		label.setFont(new Font("Aharoni", Font.PLAIN, 19));
		
		 submit = new JButton("Submit");
		submit.setBounds(37, 375, 112, 41);
		panel.add(submit);
		submit.setFont(new Font("Tahoma", Font.BOLD, 15));
		submit.addActionListener(this);
		
		  cancel = new JButton("Cancel");
		cancel.setBounds(253, 375, 112, 41);
		panel.add(cancel);
		cancel.setFont(new Font("Tahoma", Font.BOLD, 15));
		cancel.addActionListener(this);
		
		pass1 = new JPasswordField();
		pass1.setBounds(197, 116, 161, 20);
		panel.add(pass1);
		
		tname = new JTextField();
		tname.setBounds(197, 70, 161, 20);
		panel.add(tname);
		tname.setColumns(10);
		
		JLabel lblRepassword = new JLabel("Re-Password");
		lblRepassword.setFont(new Font("Aharoni", Font.PLAIN, 19));
		lblRepassword.setBounds(37, 154, 136, 35);
		panel.add(lblRepassword);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Aharoni", Font.PLAIN, 19));
		lblAddress.setBounds(37, 213, 136, 35);
		panel.add(lblAddress);
		
		JLabel lblMobileNo = new JLabel("Mobile No.");
		lblMobileNo.setFont(new Font("Aharoni", Font.PLAIN, 19));
		lblMobileNo.setBounds(37, 259, 136, 35);
		panel.add(lblMobileNo);
		
		taddress = new JTextField();
		taddress.setColumns(10);
		taddress.setBounds(193, 213, 161, 20);
		panel.add(taddress);
		
		tm_no = new JTextField();
		tm_no.setColumns(10);
		tm_no.setBounds(193, 259, 161, 20);
		panel.add(tm_no);
		
	    m =  new JRadioButton("Male");
		m.setBounds(197, 331, 97, 23);
		panel.add(m);
		
		 f = new JRadioButton("Female");
		f.setBounds(296, 331, 109, 23);
		panel.add(f);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setFont(new Font("Aharoni", Font.PLAIN, 19));
		lblGender.setBounds(37, 326, 136, 35);
		panel.add(lblGender);
		
		lblCity = new JLabel("City");
		lblCity.setFont(new Font("Aharoni", Font.PLAIN, 19));
		lblCity.setBounds(37, 293, 136, 35);
		panel.add(lblCity);
		
		 tcity = new JComboBox<String>();
		tcity.setModel(new DefaultComboBoxModel<String>(new String[] {"Select city", "Agra", "Lucknow", "Delhi", ""}));
		tcity.setBounds(193, 304, 161, 20);
		panel.add(tcity);
		
		lblId = new JLabel("Id");
		lblId.setFont(new Font("Aharoni", Font.PLAIN, 19));
		lblId.setBounds(37, 16, 109, 35);
		panel.add(lblId);
		
		tid = new JTextField();
		tid.setColumns(10);
		//tid.setEditable(false);
		tid.setBounds(197, 24, 161, 20);
		panel.add(tid);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(197, 162, 161, 20);
		panel.add(passwordField);
		
		panel_1 = new JPanel(){
				/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

				public void paintComponent(Graphics g){
					Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/signup (2).jpg"));
					g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
					
				}
			};   
		
		
		panel_1.setBounds(265, 11, 283, 82);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		 
	setVisible(true);
	}

 
@Override
public void actionPerformed(ActionEvent e) {
	Object ob=e.getSource();
	if(ob==cancel)
	{
		dispose();
		new Login();
	}
	else if(ob==submit)
	{       
		      dispose();
	 
			new Login();
			boolean q=check();
			q=true;
			if(q)
			{
				int eid=Integer.parseInt(tid.getText());
				String name=tname.getText();
				String address=taddress.getText();
				String gender="";
				if(m.isSelected())
					gender="Male";
				else
					gender="Female";
				String city=tcity.getSelectedItem().toString();
				 
				String m_no=tm_no.getText();
				String s="insert into signups (tid,tname,taddress,tm_no,tcity,tgender) "
						+ "values(?,?,?,?,?,?)";
				Connection c=MyConnections.connect();
				try{
					PreparedStatement ps=c.prepareStatement(s);
					ps.setInt(1, eid);
					ps.setString(2, name);
					ps.setString(3, address);
					ps.setString(4, m_no);
					ps.setString(5,city);
					ps.setString(6,gender);
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null, "Info Added");
					//dispose();
				}
				catch(SQLException se)
				{
					se.printStackTrace();
				}
			}
		}
	}
	boolean check()
	{
		boolean cc=true;
		String st=tname.getText().trim();
		int len=st.length();
		if(len==0)
		{
			JOptionPane.showMessageDialog(null, "Employee Name Blank");
			tname.requestFocusInWindow();
			cc=false;
		}
		if(!(m.isSelected() || f.isSelected()))
		{
			JOptionPane.showMessageDialog(null, "Gender not selected");
			m.requestFocusInWindow();
			cc=false;
		}
		return cc;
	}
}
	