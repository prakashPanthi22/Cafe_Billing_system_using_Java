package caffe;

 
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Image;
 
import javax.swing.JLabel;

import java.awt.Font;

 

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
 



 

 
import javax.swing.border.LineBorder;
 

 


public class Login extends JFrame implements ActionListener {

	 
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField lt;
	private JPasswordField lp;
	private JButton login;
	private JButton   SignUp;
	private JButton btnNewButton;
	
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 899, 654);
		contentPane = new JPanel(){
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public void paintComponent(Graphics g){
				Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/loginwall.jpg"));
				g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
				
			}
		};
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCaffemanagment = new JLabel("Cafe Management System");
		lblCaffemanagment.setForeground(Color.CYAN);
		lblCaffemanagment.setVerifyInputWhenFocusTarget(false);
		lblCaffemanagment.setBackground(new Color(240, 240, 240));
		lblCaffemanagment.setFont(new Font("Viner Hand ITC", Font.BOLD | Font.ITALIC, 42));
		lblCaffemanagment.setBounds(223, 21, 596, 74);
		contentPane.add(lblCaffemanagment);
		
		JLabel lblNewLabel = new JLabel(" ");
		lblNewLabel.setVerifyInputWhenFocusTarget(false);
		lblNewLabel.setBounds(163, 145, 385, -6);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setVerifyInputWhenFocusTarget(false);
		panel.setBorder(new LineBorder(new Color(238, 232, 170), 3, true));
		panel.setBounds(53, 190, 414, 352);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(37, 137, 109, 35);
		panel.add(lblPassword);
		lblPassword.setFont(new Font("Aharoni", Font.PLAIN, 19));
		
		JLabel label = new JLabel("Username");
		label.setBounds(37, 48, 109, 35);
		panel.add(label);
		label.setFont(new Font("Aharoni", Font.PLAIN, 19));
		
		lp = new JPasswordField();
		lp.setBounds(168, 145, 161, 20);
		panel.add(lp);
		
		lt = new JTextField();
		lt.setBounds(168, 56, 161, 20);
		panel.add(lt);
		lt.setColumns(10);
		
		JPanel panel_1 = new JPanel() {
		
		/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics g){
			Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/signupnow.jpg"));
			g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
			
		}
	};
		
		
		panel_1.setBounds(239, 221, 146, 53);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		  SignUp = new JButton(" ");
		  SignUp.setBounds(0, 0, 145, 52);
		  panel_1.add(SignUp);
		  SignUp.setFont(new Font("Tahoma", Font.BOLD, 15));
		  SignUp.addActionListener(this);
		  SignUp.setContentAreaFilled(false);
		  SignUp.setOpaque(false);
		  
		  JPanel panel_2 = new JPanel(){
				
				/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

				public void paintComponent(Graphics g){
					Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/loginss.jpg"));
					g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
					
				}
			};
				
		  panel_2.setBounds(37, 221, 119, 56);
		  panel.add(panel_2);
		  panel_2.setLayout(null);
		    
		     login = new JButton(" ");
		     login.setBounds(0, 0, 119, 54);
		     panel_2.add(login);
		     login.setFont(new Font("Tahoma", Font.BOLD, 15));
		   login.addActionListener(this);
		   login.setContentAreaFilled(false);
		   login.setOpaque(false);
		   
		     btnNewButton = new JButton("Admin View");
		     btnNewButton.setFont(new Font("Segoe Print", Font.BOLD, 15));
		   btnNewButton.addActionListener(new ActionListener() {
		   	public void actionPerformed(ActionEvent e) {
		   	}
		   });
		   btnNewButton.setBounds(124, 306, 155, 23);
		   panel.add(btnNewButton);
		   btnNewButton.addActionListener(this);
		 
		   
		   
		 
	setVisible(true);
	}

 
@Override
public void actionPerformed(ActionEvent e) {
	Object ob=e.getSource();
	if(ob==login)
	{
		dispose();
		new Billing();
	}
	else if(ob==SignUp)
	{ 
		dispose();
		new SignUp();
	}
	if(ob==btnNewButton){
		new AdminView();
}}}
