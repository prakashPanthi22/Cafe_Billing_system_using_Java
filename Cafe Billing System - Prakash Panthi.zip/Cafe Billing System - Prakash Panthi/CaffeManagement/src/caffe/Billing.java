package caffe;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
 

 

public class Billing extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField tc;
	private JTextField csgst;
	private JTextField ccgst;
	private JTextField ctc;
	private JPanel contentPane;
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JLabel actionRecived;
	private JLabel actionRecived2;
	private JLabel actionRecived3;
	private JLabel actionRecived7;
	private JLabel actionRecived6;
	private JButton Jbtbill;
	private JButton btneq; 
	private JTextField calDis;
	private JTextField tvc;
	private JTextField tcm;
	private JTextField thl;
	private JTextField tic;
	private JTextField tie;
	private JTextField tkn;
	private JTextField tdf;
	private JTextField tti;
	private JButton btnRahul;
	private JPanel ans;
	private JPanel   panel_8;
	private JButton homebutton;
	private JEditorPane txbill;
	private JTextField txtans;
	private JButton btn0;
	private JButton btndot;
	 
	
public Billing() {
	setSize(getMaximumSize());
	getContentPane().setLayout(null);
	
	//image 
		contentPane = new JPanel(){
		/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics g){
			Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/bgecc.jpg"));
			g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
			
		}
	};
	contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	setContentPane(contentPane);
	contentPane.setLayout(null);
	
	
	
	 panel = new JPanel(){
		 /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics g){
			Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/totalhot.jpg"));
			g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
			
		}
	};
	
	
	
	
	
	
	 panel.setBorder(new LineBorder(new Color(0, 0, 0), 6));
 panel.setBounds(27, 110, 361, 342);
	getContentPane().add( panel);
	 panel.setLayout(null);
	
	JLabel lblHotCoffees = new JLabel("Hot Coffees ");
	lblHotCoffees.setForeground(Color.PINK);
	lblHotCoffees.setFont(new Font("Viner Hand ITC", Font.PLAIN, 30));
	lblHotCoffees.setBounds(87, 11, 181, 37);
	panel.add(lblHotCoffees);
	
	JLabel lblVanillaCappuccine = new JLabel("Vanilla Cappuccino");
	lblVanillaCappuccine.setForeground(Color.WHITE);
	lblVanillaCappuccine.setFont(new Font("Viner Hand ITC", Font.PLAIN, 19));
	lblVanillaCappuccine.setBounds(23, 72, 189, 25);
	panel.add(lblVanillaCappuccine);
	
	JLabel lblCoffeMocha = new JLabel("Coffe Mocha");
	lblCoffeMocha.setForeground(Color.WHITE);
	lblCoffeMocha.setFont(new Font("Viner Hand ITC", Font.PLAIN, 19));
	lblCoffeMocha.setBounds(23, 128, 189, 25);
	panel.add(lblCoffeMocha);
	
	JLabel lblHazelnutLatte = new JLabel("Hazelnut Latte");
	lblHazelnutLatte.setForeground(Color.WHITE);
	lblHazelnutLatte.setFont(new Font("Viner Hand ITC", Font.PLAIN, 19));
	lblHazelnutLatte.setBounds(23, 183, 189, 25);
	panel.add(lblHazelnutLatte);
	
	JLabel lblIrishCappuccino = new JLabel("Irish Cappuccino");
	lblIrishCappuccino.setForeground(Color.WHITE);
	lblIrishCappuccino.setFont(new Font("Viner Hand ITC", Font.PLAIN, 19));
	lblIrishCappuccino.setBounds(23, 238, 189, 25);
	panel.add(lblIrishCappuccino);
	
	tvc = new JTextField();
	tvc.setText("0");
	tvc.setHorizontalAlignment(SwingConstants.RIGHT);
	tvc.setColumns(10);
	tvc.setBounds(222, 74, 129, 20);
	panel.add(tvc);
	
	tcm = new JTextField();
	tcm.setText("0");
	tcm.setHorizontalAlignment(SwingConstants.RIGHT);
	tcm.setColumns(10);
	tcm.setBounds(222, 130, 129, 20);
	panel.add(tcm);
	
	thl = new JTextField();
	thl.setText("0");
	thl.setHorizontalAlignment(SwingConstants.RIGHT);
	thl.setColumns(10);
	thl.setBounds(222, 185, 129, 20);
	panel.add(thl);
	
	tic = new JTextField();
	 tic.setText("0");
	 tic.setHorizontalAlignment(SwingConstants.RIGHT);
	 tic.setColumns(10);
	tic.setBounds(222, 240, 129, 20);
	panel.add(tic);
 
	
 panel_1 = new JPanel();
	panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 6));
	panel_1.setBounds(27, 650, 700, 63);
	getContentPane().add(panel_1);
	panel_1.setLayout(null);
	
	
	
	             //Total 
	
	JButton jbttotal = new JButton("Total");
	jbttotal.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			
	    double VanillaCappniccino=Double.parseDouble(tvc.getText());
	    double pVanillaCappniccino=250;
	    double HotCoffees;
	    HotCoffees = (VanillaCappniccino*pVanillaCappniccino);
	   String pMeal = String.format("%.2f", HotCoffees);
	    tc.setText(pMeal);
	   
	    
	    
	    
	    double  CoffeMocha=Double.parseDouble(tcm.getText());
	    double pCoffeMocha=300;
	    double HotCoffees2;                                        
	    HotCoffees2 = (CoffeMocha*pCoffeMocha);
	    String cmMeal = String.format("%.2f", HotCoffees2 + HotCoffees);
	    tc.setText(cmMeal);
	    
	    
	    double  Hazelnut=Double.parseDouble(thl.getText());
	    double pHazelnut=250;
	    double HotCoffees3;                                          
	    HotCoffees3 = (Hazelnut*pHazelnut);
	    String hlMeal = String.format("%.2f",  HotCoffees3 + HotCoffees2 + HotCoffees);
	    tc.setText(hlMeal);
	    
	    
	    
	 double irish=Double.parseDouble(tic.getText());
	  double pirish=180;
	    double HotCoffees4;
	    HotCoffees4 = (irish*pirish);
	    String irMeal = String.format("%.2f",  HotCoffees4 + HotCoffees3 + HotCoffees2 + HotCoffees);
	    tc.setText(irMeal);
	    
	    

	    double  IcedEskimo=Double.parseDouble(tie.getText());
	    double pIcedEskimo=250;
	    double coldCoffees5;
	    coldCoffees5 = (IcedEskimo*pIcedEskimo);
	    String ieMeal = String.format("%.2f", coldCoffees5 + HotCoffees4 + HotCoffees3 +HotCoffees2 + HotCoffees);
	    tc.setText(ieMeal);
	    
	    

	    double  kaapiNirwana=Double.parseDouble(tkn.getText());
	    double pkaapiNirwana=100;
	    double coldCoffees11;
	    coldCoffees11 = (kaapiNirwana*pkaapiNirwana);
	    String keMeal = String.format("%.2f", coldCoffees11 + coldCoffees5 + HotCoffees4 + HotCoffees3 + HotCoffees2 + HotCoffees);
	    tc.setText(keMeal);
	    
	    
	    
	    double  DarkFrappa=Double.parseDouble(tdf.getText());
	    double pDarkFrappa=150;
	    double coldCoffees2;
	    coldCoffees2 = (DarkFrappa*pDarkFrappa);
	    String dfMeal = String.format("%.2f", coldCoffees2  +  coldCoffees11 + coldCoffees5 + HotCoffees4 + HotCoffees3 + HotCoffees2 + HotCoffees);
	    tc.setText(dfMeal);
	    
	    
	    
	    double  TropicalIceberg=Double.parseDouble(tti.getText());
	    double pTropicalIceberg=200;
	    double coldCoffees7;
	    coldCoffees7 = (TropicalIceberg*pTropicalIceberg);
	    String tiMeal = String.format("%.2f", coldCoffees7 + coldCoffees2  +   coldCoffees11 + coldCoffees5 + HotCoffees4 + HotCoffees3 + HotCoffees2 + HotCoffees);
	    tc.setText(tiMeal);
	    
	    
	    
	    
	    double  tax1=Double.parseDouble(tc.getText());
	    // double tax1;
	    // tax1=(   coldCoffees7 + coldCoffees2  +   coldCoffees11 + coldCoffees5 + HotCoffees4 + HotCoffees3 + HotCoffees2 + HotCoffees/100 );
	     String csgst1 = String.format("%.2f",tax1/100*8);
	      csgst.setText(csgst1);
	      
	      
	      
	      

		    double  tax2=Double.parseDouble(tc.getText());
		     //double tax3;
		     //tax3=(   coldCoffees7 + coldCoffees2  +   coldCoffees11 + coldCoffees5 + HotCoffees4 + HotCoffees3 + HotCoffees2 + HotCoffees/100 );
		     String ccgst1 = String.format("%.2f",tax2/100*9);
		     ccgst.setText(ccgst1);
			
		     
		     //total
		   


			    double  tax5=Double.parseDouble(tc.getText());
			    double  tax7=Double.parseDouble(csgst.getText());
			    double  tax11=Double.parseDouble(ccgst.getText());
			     //double tax6;
			     //tax6=(   coldCoffees7 + coldCoffees2  +   coldCoffees11 + coldCoffees5 + HotCoffees4 + HotCoffees3 + HotCoffees2 + HotCoffees/100 );
			     String ccgst6 = String.format("%.2f",tax5+tax7+tax11);
			     ctc.setText(ccgst6);
			
			
		}
	});
	jbttotal.setBounds(67, 11, 89, 41);
	panel_1.add(jbttotal);
	
	Jbtbill = new JButton("Bill");
	Jbtbill.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			 
		    double  vanic=Double.parseDouble(tvc.getText());
			double b11=250;
			double b122=(vanic* b11);
			
			double  coffeMocha=Double.parseDouble(tcm.getText());
			double b111=300;
			double b1221=(coffeMocha * b111);
			
			double  haz=Double.parseDouble(thl.getText());
			double b112=250;
			double b1222=(haz * b112);
			
			double icp=Double.parseDouble(tti.getText());
			double b113=180;
			double b1223=(icp * b113);
			
			double  icek=Double.parseDouble(tic.getText());
			double b114=250;
			double b1224=(icek * b114);
			
			double  kaapi=Double.parseDouble(tkn.getText());
			double b115=190;
			double b1225=(kaapi * b115);
			
			double dark=Double.parseDouble(tdf.getText());
			double b116=150;
			double b1226=(dark * b116);
			
			double  trop=Double.parseDouble(tie.getText());
			double b117=200;
			double b1227=(trop* b117);
			
			double  Cost=Double.parseDouble(tc.getText());
			 
			double  gst1=Double.parseDouble(csgst.getText());
			double  gst2=Double.parseDouble(ccgst.getText());
			double  total=Double.parseDouble(ctc.getText());
			
			
			//=============================================================
			txbill.setText(" Caffee Management System:\t  \n " +
		 " \n \n Vanilla Cappnccino : "   + b122 + 
		      "  \n \n Coffe Mocha: "     + b1221 +
			  " \n \n Hazelnut Lattle:"   +b1222 + 
			  " \n \n Irish Cappuccino:"  + b1223 +
			  " \n \n Ireda Eskimo:"      +b1224 +
			  "\n \n  Kappi Nirvana:"     + b1225 +
			  " \n \n Dark Frappe:"       + b1226 +
			  " \n \n Tropical Iceberq:"  + b1227 +  
			  " \n \n \t Cost:"  + Cost +  
			  " \n \t SGST:"  + gst1 + 
			  " \n \t CGST:"  + gst2 +  
			  " \n \t Total:"  + total +  
			  " \n \n \t Thank you"  );
			
		}
	});
	Jbtbill.setBounds(520, 11, 89, 41);
	panel_1.add(Jbtbill);
	
	
	                //Action Null For RESET BUTTON   
	
	
	
	
	
	JButton jbtreset = new JButton("Reset");
	jbtreset.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			tc.setText(null);
			csgst.setText(null);
			ccgst.setText(null);
			ctc.setText("");
		    tcm.setText("0");
		    tvc.setText("0");
		    thl.setText("0");
		    tic.setText("0");
		    tie.setText("0");
		    tkn.setText("0");
		    tdf.setText("0");
		    tti.setText("0");
		    tc.setText("0");
		    csgst.setText("0");
		    ccgst.setText("0");
		    ctc.setText("0");
		     
		    
		    
		}
	});
	jbtreset.setBounds(300, 11, 89, 41);
	panel_1.add(jbtreset);
	
	 panel_2 = new JPanel(){
		  /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics g){
				Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/totalcold.jpg"));
				g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );			
				} };
	 panel_2.setForeground(Color.WHITE);
	panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 6));
	panel_2.setBounds(415, 110, 312, 342);
	getContentPane().add(panel_2);
	panel_2.setLayout(null);
	
	JLabel lblColdCoffees = new JLabel("Cold Coffees ");
	lblColdCoffees.setForeground(Color.PINK);
	lblColdCoffees.setFont(new Font("Viner Hand ITC", Font.PLAIN, 30));
	lblColdCoffees.setBounds(58, 11, 181, 37);
	panel_2.add(lblColdCoffees);
	
	JLabel lblIcedEskimo = new JLabel("Iced Eskimo");
	lblIcedEskimo.setForeground(Color.WHITE);
	lblIcedEskimo.setFont(new Font("Viner Hand ITC", Font.PLAIN, 19));
	lblIcedEskimo.setBounds(10, 72, 146, 25);
	panel_2.add(lblIcedEskimo);
	
	JLabel lblKaapiNirvana = new JLabel("Kaapi Nirvana");
	lblKaapiNirvana.setForeground(Color.WHITE);
	lblKaapiNirvana.setFont(new Font("Viner Hand ITC", Font.PLAIN, 19));
	lblKaapiNirvana.setBounds(10, 127, 155, 25);
	panel_2.add(lblKaapiNirvana);
	
	JLabel lblDarkFrappe = new JLabel("Dark Frappe");
	lblDarkFrappe.setForeground(Color.WHITE);
	lblDarkFrappe.setFont(new Font("Viner Hand ITC", Font.PLAIN, 19));
	lblDarkFrappe.setBounds(10, 179, 155, 25);
	panel_2.add(lblDarkFrappe);
	
	JLabel lblTropicalIceberg = new JLabel("Tropical Iceberg");
	lblTropicalIceberg.setForeground(Color.WHITE);
	lblTropicalIceberg.setFont(new Font("Viner Hand ITC", Font.PLAIN, 19));
	lblTropicalIceberg.setBounds(10, 276, 161, 25);
	panel_2.add(lblTropicalIceberg);
	
	tie = new JTextField();
	tie.setText("0");
	tie.setHorizontalAlignment(SwingConstants.RIGHT);
	tie.setColumns(10);
	tie.setBounds(173, 74, 129, 20);
	panel_2.add(tie);
	
	tkn = new JTextField();
	tkn.setText("0");
	tkn.setHorizontalAlignment(SwingConstants.RIGHT);
	tkn.setColumns(10);
	tkn.setBounds(173, 129, 129, 20);
	panel_2.add(tkn);
	
	tdf = new JTextField();
	tdf.setText("0");
	tdf.setHorizontalAlignment(SwingConstants.RIGHT);
	tdf.setColumns(10);
	tdf.setBounds(173, 181, 129, 20);
	panel_2.add(tdf);
	
	tti = new JTextField();
	tti.setForeground(Color.BLACK);
	tti.setText("0");
	tti.setHorizontalAlignment(SwingConstants.RIGHT);
	tti.setColumns(10);
	tti.setBounds(173, 278, 129, 20);
	panel_2.add(tti);
	
	JPanel panel_3 = new JPanel(){
 

	 /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

	public void paintComponent(Graphics g){
 		Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/totalwall.jpg"));
 		g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
	 		}};
	panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 6));
	panel_3.setBounds(149, 463, 411, 176);
	getContentPane().add(panel_3);
	panel_3.setLayout(null);
	
	JLabel lblCost = new JLabel("Cost");
	lblCost.setForeground(Color.WHITE);
	lblCost.setFont(new Font("Viner Hand ITC", Font.PLAIN, 24));
	lblCost.setBounds(41, 27, 112, 25);
	panel_3.add(lblCost);
	
	JLabel lblSgat = new JLabel("SGST");
	lblSgat.setForeground(Color.WHITE);
	lblSgat.setFont(new Font("Viner Hand ITC", Font.PLAIN, 24));
	lblSgat.setBounds(41, 63, 112, 25);
	panel_3.add(lblSgat);
	
	JLabel lblCgst = new JLabel("CGST");
	lblCgst.setForeground(Color.WHITE);
	lblCgst.setFont(new Font("Viner Hand ITC", Font.PLAIN, 24));
	lblCgst.setBounds(41, 99, 112, 25);
	panel_3.add(lblCgst);
	
	JLabel lblTotalCost = new JLabel("Total Cost");
	lblTotalCost.setForeground(Color.WHITE);
	lblTotalCost.setFont(new Font("Viner Hand ITC", Font.PLAIN, 25));
	lblTotalCost.setBounds(41, 135, 129, 25);
	panel_3.add(lblTotalCost);
	
	tc = new JTextField();
	tc.setHorizontalAlignment(SwingConstants.RIGHT);
	tc.setColumns(10);
	tc.setBounds(180, 27, 196, 20);
	panel_3.add(tc);
	
	csgst = new JTextField();
	csgst.setHorizontalAlignment(SwingConstants.RIGHT);
	csgst.setColumns(10);
	csgst.setBounds(180, 63, 196, 20);
	panel_3.add(csgst);
	
	ccgst = new JTextField();
	ccgst.setHorizontalAlignment(SwingConstants.RIGHT);
	ccgst.setColumns(10);
	ccgst.setBounds(181, 99, 196, 20);
	panel_3.add(ccgst);
	
	ctc = new JTextField();
	ctc.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			
		}
	});
	ctc.setHorizontalAlignment(SwingConstants.RIGHT);
	ctc.setColumns(10);
	ctc.setBounds(180, 138, 196, 20);
	panel_3.add(ctc);
	
 
	
	JLabel lblPrakashC = new JLabel("Cafe Management System");
	lblPrakashC.setFont(new Font("Brush Script MT", Font.BOLD | Font.ITALIC, 75));
	lblPrakashC.setBounds(268, 11, 750, 88);
	getContentPane().add(lblPrakashC);
	
	JPanel panel_4 = new JPanel(){
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics g){
			Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/images(12).jpg"));
			g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
			}};
	
	panel_4.setBorder(new LineBorder(new Color(0, 0, 0), 5));
	panel_4.setBounds(749, 110, 269, 603);
	contentPane.add(panel_4);
	panel_4.setLayout(null);
	
	JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	tabbedPane.setBounds(10, 40, 250, 551);
	panel_4.add(tabbedPane);
	
	final JButton btnsc;
	final JButton btnc;
	final JButton btnp;
	final JButton btna;
	final JButton btns;
	 final JButton btn9;
	final JButton btn8;
	final JButton btn7;
	final JButton btnm;
	final JButton btn6;
	final JButton btn5;
	final JButton btn4;
	final JButton btn1;
    final JButton btn2;
	final JButton btn3;
	final JButton btnd;
	
	JPanel panel_7 = new JPanel();
	tabbedPane.addTab("Bill", null, panel_7, null);
	panel_7.setLayout(null);
	
	txbill = new JEditorPane();
	txbill.setEditable(false);
	txbill.setBackground(Color.white);
//	txbill.setHorizontalAlignment(SwingConstants.LEFT);
	txbill.setText("Caffee Billing");
	txbill.setBounds(0, 11, 255, 460);
	panel_7.add(txbill);
//	txbill.setColumns(10);
	
  
	
	JPanel panel_6 = new JPanel(){
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics g){
			Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/calc.jpg"));
			g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
			}};
	
	
	tabbedPane.addTab("Calculator", null, panel_6, null);
	panel_6.setLayout(null);
	btnsc = new JButton("<");
	btnsc.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String backspace=null;
			
			if(calDis.getText().length()>0){
		StringBuilder strb=new StringBuilder(calDis.getText());
		strb.deleteCharAt(calDis.getText().length()-1);
		backspace =strb.toString();
		calDis.setText(backspace);
	}
		}
	});
	btnsc.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btnsc.setBounds(0, 81, 53, 61);
	panel_6.add(btnsc);
	
	calDis = new JTextField();
	calDis.setFont(new Font("Tahoma", Font.PLAIN, 14));
	calDis.setColumns(10);
	calDis.setBounds(10, 17, 225, 53);
	panel_6.add(calDis);
	btnc = new JButton("C");
	btnc.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			calDis.setText("0");
			txtans.setText("0");
			actionRecived.setText(null);
			actionRecived2.setText(null);
			actionRecived3.setText(null);
			actionRecived7.setText(null);
			actionRecived6.setText(null);
			}
	});
	btnc.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btnc.setBounds(63, 81, 53, 61);
	panel_6.add(btnc);
	btnp = new JButton("%");
	btnp.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			txtans.setText(calDis.getText());
			calDis.setText(null);
			actionRecived3.setText("per");
			
		}
	});
	btnp.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btnp.setBounds(126, 81, 53, 61);
	panel_6.add(btnp);
	
	
	btna = new JButton("+");
	btna.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			txtans.setText(calDis.getText());
			calDis.setText(null);
			actionRecived.setText("add");
			
		}
	});
	btna.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btna.setBounds(189, 81, 53, 61);
	panel_6.add(btna);
	
	btns = new JButton("-");
	btns.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			txtans.setText(calDis.getText());
			calDis.setText(null);
			actionRecived2.setText("sub");
			
		}
	});
	btns.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btns.setBounds(189, 161, 53, 61);
	panel_6.add(btns);
	btn9 = new JButton("9");
	btn9.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String EnterNumber=calDis.getText()+ btn9.getText();
			calDis.setText(EnterNumber);
		}
	});
	btn9.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btn9.setBounds(126, 161, 53, 61);
	panel_6.add(btn9);
	btn8 = new JButton("8");
	btn8.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String EnterNumber=calDis.getText()+ btn8.getText();
			calDis.setText(EnterNumber);
		}
	});
	btn8.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btn8.setBounds(63, 161, 53, 61);
	panel_6.add(btn8);
	btn7 = new JButton("7");
	btn7.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String EnterNumber=calDis.getText()+ btn7.getText();
			calDis.setText(EnterNumber);
		}
	});
	btn7.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btn7.setBounds(0, 161, 53, 61);
	panel_6.add(btn7);
	btnm = new JButton("*");
	btnm.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			txtans.setText(calDis.getText());
			calDis.setText(null);
			actionRecived6.setText("mul");
			
		}
	});
	btnm.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btnm.setBounds(189, 252, 53, 61);
	panel_6.add(btnm);
	btn6 = new JButton("6");
	btn6.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String EnterNumber=calDis.getText()+ btn6.getText();
			calDis.setText(EnterNumber);
		}
	});
	btn6.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btn6.setBounds(126, 252, 53, 61);
	panel_6.add(btn6);
	btn5 = new JButton("5");
	btn5.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			btn5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String EnterNumber=calDis.getText()+ btn5.getText();
					calDis.setText(EnterNumber);
				}
			});
		}
	});
	btn5.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btn5.setBounds(63, 252, 53, 61);
	panel_6.add(btn5);
	btn4 = new JButton("4");
	btn4.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String EnterNumber=calDis.getText()+ btn4.getText();
			calDis.setText(EnterNumber);
		}
	});
	
	btn4.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btn4.setBounds(0, 252, 53, 61);
	panel_6.add(btn4);
	btn1 = new JButton("1");
	btn1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String EnterNumber=calDis.getText()+ btn1.getText();
			calDis.setText(EnterNumber);
		}
	});
	btn1.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btn1.setBounds(0, 350, 53, 61);
	panel_6.add(btn1);
	btn2 = new JButton("2");
	btn2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String EnterNumber=calDis.getText()+ btn2.getText();
			calDis.setText(EnterNumber);
		}
	});
	btn2.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btn2.setBounds(63, 350, 53, 61);
	panel_6.add(btn2);
	btn3 = new JButton("3");
	btn3.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String EnterNumber=calDis.getText()+ btn3.getText();
			calDis.setText(EnterNumber);
		}
	});
	btn3.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btn3.setBounds(126, 350, 53, 61);
	panel_6.add(btn3);
	btnd = new JButton("/");
	btnd.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			txtans.setText(calDis.getText());
			calDis.setText(null);
			actionRecived7.setText("div");
			
		}
	});
	btnd.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btnd.setBounds(189, 350, 53, 61);
	panel_6.add(btnd);
	
	
	                //-------------- == -------------
	 
	 btneq = new JButton("=");
	btneq.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			double one=Double.parseDouble(txtans.getText());
			double two=Double.parseDouble(calDis.getText());
			if(actionRecived.getText().equals("add"))
			{
				calDis.setText(String.valueOf(one+two));
			}
			
			else if(actionRecived2.getText().equals("sub"))
			{
				calDis.setText(String.valueOf(one-two));
			}
			
			else if(actionRecived3.getText().equals("per"))
			{
				calDis.setText(String.valueOf(one%two));
			}
			else if(actionRecived7.getText().equals("div"))
			{
				calDis.setText(String.valueOf(one / two));
			}
			else if(actionRecived6.getText().equals("mul"))
			{
				calDis.setText(String.valueOf(one*two));
			}
		}
	});
	btneq.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btneq.setBounds(141, 454, 88, 61);
	panel_6.add(btneq);
	
	  btndot = new JButton(".");
	btndot.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String EnterNumber=calDis.getText()+ btndot.getText();
			calDis.setText(EnterNumber);
		}
	});
	btndot.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btndot.setBounds(63, 454, 53, 61);
	panel_6.add(btndot);
	
	  btn0 = new JButton("0");
	btn0.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String EnterNumber=calDis.getText()+ btn0.getText();
			calDis.setText(EnterNumber);
			
		}
	});
	btn0.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btn0.setBounds(0, 454, 53, 61);
	panel_6.add(btn0);
	
	 actionRecived = new JLabel(" ");
	 actionRecived.setForeground(Color.WHITE);
	actionRecived.setBounds(204, 0, 38, 14);
	panel_6.add(actionRecived);
	
	 actionRecived2 = new JLabel(" ");
	 actionRecived2.setForeground(Color.WHITE);
	actionRecived2.setBounds(163, 0, 38, 14);
	panel_6.add(actionRecived2);
	
	 actionRecived3 = new JLabel(" ");
	 actionRecived3.setForeground(Color.WHITE);
	actionRecived3.setBounds(115, 0, 38, 14);
	panel_6.add(actionRecived3);
	
  actionRecived7 = new JLabel(" ");
  actionRecived7.setForeground(Color.WHITE);
	actionRecived7.setBounds(63, 0, 38, 14);
	panel_6.add(actionRecived7);
	
 actionRecived6 = new JLabel(" ");
 actionRecived6.setForeground(Color.WHITE);
	actionRecived6.setBounds(10, 0, 38, 14);
	panel_6.add(actionRecived6);
	
	 ans = new JPanel();
	ans.setBounds(138, 11, 121, 45);
	panel_4.add(ans);
	ans.setLayout(null);
	
	txtans = new JTextField();
	txtans.setBounds(0, 0, 121, 45);
	ans.add(txtans);
	txtans.setColumns(10);
	
 
	
	 panel_8 = new JPanel() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics g) {
			Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/menu.png"));
			g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
			}};
	panel_8.setBounds(169, 26, 77, 73);
	
	contentPane.add(panel_8);
	panel_8.setLayout(null);
	
	  btnRahul = new JButton("");
	  btnRahul.setContentAreaFilled(false);
	  btnRahul.setOpaque(false);
	btnRahul.setBounds(0, 0, 75, 73);
	panel_8.add(btnRahul);
	btnRahul.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			Object butt=e.getSource();
			if(butt==btnRahul)
			{
				dispose();
				new Menu();
			
			}
		
		}
	});
	
	
	
	 
	
	
	
	
	setVisible(true);
	
	
	
	
	
	JPanel panel_5 = new JPanel()
	{/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

	public void paintComponent(Graphics g){
		Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/home.jpg"));
		g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
		}};
	panel_5.setBounds(29, 26, 77, 73);
	contentPane.add(panel_5);
	panel_5.setLayout(null);

	 homebutton = new JButton(" ");
	 homebutton.addActionListener(new ActionListener() {
	 	public void actionPerformed(ActionEvent e) {
	 		Object ob=e.getSource();
	 		if(ob==homebutton)
	 		{
	 			dispose();
	 			new Home();
	 		}
	 		
	 	}
	 });
	homebutton.setContentAreaFilled(false);
	homebutton.setOpaque(false);
	homebutton.setBounds(0, 0, 77, 73);
	panel_5.add(homebutton);

	}
	
	



public static void main (String[] args)
{ new Billing();
 
}


@Override
public void actionPerformed(ActionEvent e) {
	Object ob=e.getSource();
	if(ob==homebutton)
	{
		dispose();
		new Home();
	}
	else{
	 dispose();
	 new Billing();
	}
} 
}

 