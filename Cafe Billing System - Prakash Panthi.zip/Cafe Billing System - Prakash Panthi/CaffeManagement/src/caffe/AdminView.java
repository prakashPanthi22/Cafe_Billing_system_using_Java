package caffe;

 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class AdminView {
	 JDialog dialog;
		int cnt,r,c;
		JTable table;
		JScrollPane jsp;
		JButton b;
		String []columns;
		String [][]data;

		public AdminView(){
			String s="select * from signups";
			Connection con=MyConnections.connect();
			try
			{
				PreparedStatement ps=con.prepareStatement(s);
				ResultSet rs=ps.executeQuery();
				rs.last();
			  	cnt=rs.getRow();
				rs.beforeFirst();
				columns=new String[]{"E_id","Name","Address","Mobile No.","City","Gender"};
				data=new String[cnt][6];
				while(rs.next())
				{ 
					data[r][c]=String.valueOf(rs.getInt("tid"));
					++c;
					data[r][c]=rs.getString("tname");
					++c;
					data[r][c]=rs.getString("taddress");
					++c;
					data[r][c]=rs.getString("tm_no");
					++c;
					data[r][c]=rs.getString("tcity");
					++c;
					data[r][c]=rs.getString("tgender"); 
					c=0;
					++r;
				}table=new JTable(data,columns);
				table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				jsp=new JScrollPane(table,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				dialog=new JDialog();
				dialog.setModal(true);
			 	dialog.setSize(500,400);
				dialog.getContentPane().setLayout(null);
				dialog.setLocation(100,80);
				 b=new JButton("Back");
				b.addActionListener(new ActionListener() {
					
					 
					
					@Override
					public void actionPerformed(ActionEvent e) {
						
						dialog.dispose();
					}
				}); 
					 
					 
				b.setBounds(10,10,80,30);
				jsp.setBounds(10,60,451,200);
				dialog.getContentPane().add(b);
				dialog.getContentPane().add(jsp);
				dialog.setVisible(true);
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
		}
}
