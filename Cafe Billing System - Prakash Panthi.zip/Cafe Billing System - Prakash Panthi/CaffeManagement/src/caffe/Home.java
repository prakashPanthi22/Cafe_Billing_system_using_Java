package caffe;

 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.event.AncestorListener;
import javax.swing.event.AncestorEvent;

 
 
public class Home extends JFrame implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane1;
	private JButton startbtn;

	public Home() {
		setSize(getMaximumSize());
		getContentPane().setLayout(null);
		
		

		contentPane1 = new JPanel(){

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public void paintComponent(Graphics g){
				Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/home22.jpg"));
				g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
				
			}
		};
		contentPane1.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane1);
		contentPane1.setLayout(null);
		 
		 JLabel lblCaffeeManagementSystem = new JLabel("Welcome To Cafe Management System");
		 lblCaffeeManagementSystem.setForeground(new Color(51, 0, 153));
		 lblCaffeeManagementSystem.setFont(new Font("Script MT Bold", Font.BOLD | Font.ITALIC, 40));
		 lblCaffeeManagementSystem.setBounds(10, 605, 724, 99);
		 getContentPane().add(lblCaffeeManagementSystem);
		 
		 JPanel panel = new JPanel(){ 

				/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

				public void paintComponent(Graphics g){
					Image img = Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/images/start22.png"));
					g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this );
					
				}
			};
		 panel.addAncestorListener(new AncestorListener() {
		 	public void ancestorAdded(AncestorEvent event) {
		 	}
		 	public void ancestorMoved(AncestorEvent event) {
		 	}
		 	public void ancestorRemoved(AncestorEvent event) {
		 	}
		 });
		 
		 
		 panel.setBounds(744, 605, 239, 99);
		 contentPane1.add(panel);
		 panel.setLayout(null);
			startbtn = new JButton(" ");
			startbtn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				Object butt=e.getSource();
					if(butt==startbtn)
					{
						dispose();
						new Login();
					
					}
				
				}
			});
			startbtn.setBounds(742, 605, 239, 99);
			contentPane1.add(startbtn);
			startbtn.setOpaque(false);
			startbtn.setContentAreaFilled(false);
		 setVisible(true);
		 
}

	@Override
	public void actionPerformed(ActionEvent e) {
 
		
	}

	public static void main(String args[]) {
		new Home();
	
}
}
